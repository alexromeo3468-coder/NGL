# NGL DGL Shop

This is a simple shop website for **NGL DGL**, ready to deploy on GitHub Pages or Vercel.

### How to Deploy on Vercel
1. Push this repo to GitHub.
2. Go to [Vercel](https://vercel.com/new) → Import your GitHub repo.
3. Deploy → Done 🚀
